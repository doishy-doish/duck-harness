# CPU test package — scorecard failure replication (no GPU burned)

## What this proves on a free CPU notebook
- **Test A**: the 15-minute idle scorecard close is real and reproduces the
  0.00 signature (close at ~60s with STALE_MINUTES=1, blind play after close
  scores nothing and raises nothing).
- **Test B**: the staged keep-alive patch keeps the shared card open while
  the analyzer never answers (startup starvation), using the real patched
  HarnessSolver — no model server needed.

## Operator runbook (Kaggle CPU notebook, ~15 min, 0 GPU quota)
1. Create a new notebook, accelerator **None/CPU**, internet **ON**.
2. Attach the competition dataset containing `environment_files`
   (the same one the GPU notebook uses).
3. Cell 1 — install + fetch bundle:
```python
!pip install -q arc-agi arcengine flask pydantic requests
import os, urllib.request, zipfile
os.makedirs("/kaggle/working/cpu_bundle", exist_ok=True)
url = "PUT_CPU_BUNDLE_URL_HERE"  # from the assistant
dst = "/kaggle/working/cpu_bundle.zip"
urllib.request.urlretrieve(url, dst)
with zipfile.ZipFile(dst) as z:
    z.extractall("/kaggle/working")
print("bundle ready:", sorted(os.listdir("/kaggle/working/cpu_bundle")))
```
4. Cell 2 — locate env files and run Test A:
```python
import glob
cands = glob.glob("/kaggle/input/**/environment_files", recursive=True)
print(cands)
```
```python
import os
os.environ["ENV_FILES"] = cands[0]  # pick the competition one
os.environ["CPU_BUNDLE"] = "/kaggle/working/cpu_bundle"
!cd /kaggle/working/cpu_bundle/tests && python test_a_idle_close.py
```
   Expect: run1 card closed after idle + blind RESET scores 0 silently;
   run2 card open after keep-alive RESETs.
5. Cell 3 — run Test B (~8 min):
```python
!cd /kaggle/working/cpu_bundle/tests && python test_b_keepalive.py
```
   Expect: B1 log has NO `startup keep-alive RESET` lines; B2 log shows
   them about every 30s while games stall.
6. Paste back: the `run1/run2` GET lines (Test A) and the keep-alive
   RESET lines (Test B), or the full traceback if anything fails.

## If Test A shows the card did NOT close after 75s idle
That means the sweep is not lazy on GET in this version — extend the idle
to 150s and re-run; if still open, paste the GET output and stop (the
gateway may differ from 0.9.9).

## If Test B fails to import
Paste the traceback. Likely causes: version skew in arc-agi/arcengine
wheels (pin from the failure message) or a missing env dir.
